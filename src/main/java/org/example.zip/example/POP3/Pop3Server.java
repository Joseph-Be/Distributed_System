package org.example.POP3;

import java.io.*;
import java.net.*;
import java.util.*;

import org.example.common.ServerEventListener;
import org.example.database.EmailDAO;
import org.example.database.MailMessageDB;
import org.example.database.UserDAO;

public class Pop3Server {
    // Le serveur utilise maintenant le port via le contrôleur
}

class Pop3Session extends Thread {
    private Socket socket;
    private BufferedReader in;
    private PrintWriter out;
    private String username;
    private boolean authenticated;
    private Pop3ServerController controller;
    private ServerEventListener listener;
    private String clientId;
    
    // Cache for current session
    private List<MailMessageDB> emails;
    private Set<Integer> markedForDeletion;

    public Pop3Session(Socket socket,
                       Pop3ServerController controller,
                       ServerEventListener listener,
                       String clientId) {
        this.socket = socket;
        this.controller = controller;
        this.listener = listener;
        this.clientId = clientId;
        this.authenticated = false;
        this.markedForDeletion = new HashSet<>();
    }

    @Override
    public void run() {
        try {
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out = new PrintWriter(socket.getOutputStream(), true);

            sendResponse("+OK POP3 server ready");

            String line;
            while ((line = in.readLine()) != null) {
                logCommand(line);

                String[] parts = line.split(" ", 2);
                String command = parts[0].toUpperCase();
                String argument = parts.length > 1 ? parts[1] : "";

                switch (command) {
                    case "USER":
                        handleUser(argument);
                        break;
                    case "PASS":
                        handlePass(argument);
                        break;
                    case "STAT":
                        handleStat();
                        break;
                    case "LIST":
                        handleList(argument);
                        break;
                    case "RETR":
                        handleRetr(argument);
                        break;
                    case "DELE":
                        handleDele(argument);
                        break;
                    case "RSET":
                        handleRset();
                        break;
                    case "NOOP":
                        handleNoop();
                        break;
                    case "QUIT":
                        handleQuit();
                        return;
                    case "UIDL":
                        handleUidl(argument);
                        break;
                    case "TOP":
                        handleTop(argument);
                        break;
                    default:
                        sendResponse("-ERR Unknown command");
                        break;
                }
            }

            if (authenticated) {
                String msg = "Connection interrupted without QUIT. Deleted messages will not be applied.";
                logger(msg);
            }

        } catch (IOException e) {
            String msg = "Connection error: " + e.getMessage();
            logger(msg);
        } finally {
            try {
                socket.close();
            } catch (IOException ignored) {}
            controller.removeClient(socket, clientId);
        }
    }

    private void logCommand(String message) {
        if (listener != null) {
            listener.onLog(clientId + " -> " + message);
        }
    }

    private void logResponse(String message) {
        if (listener != null) {
            listener.onLog("server -> " + message);
        }
    }

    private void logger(String message) {
        if (listener != null) {
            listener.onLog(clientId + " ** " + message);
        }
        System.out.println(message);
    }

    private void sendResponse(String message) {
        out.println(message);
        logResponse(message);
    }

    private void handleUser(String arg) {
        if (authenticated) {
            sendResponse("-ERR Already authenticated");
            return;
        }

        if (arg.isEmpty()) {
            sendResponse("-ERR Username required");
            return;
        }

        // Check if user exists in database
        if (!UserDAO.userExists(arg)) {
            sendResponse("-ERR User not found");
            return;
        }

        username = arg;
        sendResponse("+OK User accepted");
    }

    private void handlePass(String arg) {
        if (username == null) {
            sendResponse("-ERR USER required first");
            return;
        }

        if (authenticated) {
            sendResponse("-ERR Already authenticated");
            return;
        }

        if (arg.isEmpty()) {
            sendResponse("-ERR Password required");
            return;
        }

        // Authenticate using database
        if (!UserDAO.authenticate(username, arg)) {
            sendResponse("-ERR Invalid password");
            return;
        }

        authenticated = true;
        
        // Load emails from database
        loadEmailsFromDatabase();
        
        // Clear deletion marks for new session
        markedForDeletion.clear();

        sendResponse("+OK Password accepted");
    }

    private void loadEmailsFromDatabase() {
        try {
            emails = EmailDAO.fetchEmails(username);
            logger("Loaded " + emails.size() + " emails from database");
        } catch (Exception e) {
            logger("Error loading emails: " + e.getMessage());
            emails = new ArrayList<>();
        }
    }

    private void handleStat() {
        if (!authenticated) {
            sendResponse("-ERR Authentication required");
            return;
        }

        // Refresh emails from database
        refreshEmails();

        int count = getActiveEmailCount();
        long totalSize = getTotalEmailSize();

        sendResponse("+OK " + count + " " + totalSize);
    }

    private void handleList(String argument) {
        if (!authenticated) {
            sendResponse("-ERR Authentication required");
            return;
        }

        refreshEmails();

        if (argument.isEmpty()) {
            // Send list of all messages
            sendResponse("+OK " + getActiveEmailCount() + " messages");
            
            int index = 1;
            for (MailMessageDB email : emails) {
                if (!isMarkedForDeletion(email.getId())) {
                    sendResponse(index + " " + email.getContent().length());
                    index++;
                }
            }
            sendResponse(".");
        } else {
            // Send specific message
            try {
                int msgNum = Integer.parseInt(argument);
                MailMessageDB email = getEmailByMsgNumber(msgNum);
                
                if (email == null) {
                    sendResponse("-ERR No such message");
                } else {
                    sendResponse("+OK " + msgNum + " " + email.getContent().length());
                }
            } catch (NumberFormatException e) {
                sendResponse("-ERR Invalid message number");
            }
        }
    }

    private void handleRetr(String argument) {
        if (!authenticated) {
            sendResponse("-ERR Authentication required");
            return;
        }

        refreshEmails();

        try {
            int msgNum = Integer.parseInt(argument);
            MailMessageDB email = getEmailByMsgNumber(msgNum);
            
            if (email == null) {
                sendResponse("-ERR No such message");
                return;
            }

            String emailContent = email.toEmailFormat();
            sendResponse("+OK " + emailContent.length() + " octets");

            // Send email content line by line
            String[] lines = emailContent.split("\r\n");
            for (String line : lines) {
                // Escape lines starting with dot
                if (line.startsWith(".")) {
                    line = "." + line;
                }
                sendResponse(line);
            }
            sendResponse(".");
            
            // Mark as seen in database
            EmailDAO.markEmailSeen(email.getId(), username);
            
        } catch (NumberFormatException e) {
            sendResponse("-ERR Invalid message number");
        }
    }

    private void handleDele(String argument) {
        if (!authenticated) {
            sendResponse("-ERR Authentication required");
            return;
        }

        refreshEmails();

        try {
            int msgNum = Integer.parseInt(argument);
            MailMessageDB email = getEmailByMsgNumber(msgNum);
            
            if (email == null) {
                sendResponse("-ERR No such message");
                return;
            }

            if (markedForDeletion.contains(email.getId())) {
                sendResponse("-ERR Message already marked for deletion");
                return;
            }

            markedForDeletion.add(email.getId());
            sendResponse("+OK Message marked for deletion");
            
        } catch (NumberFormatException e) {
            sendResponse("-ERR Invalid message number");
        }
    }

    private void handleRset() {
        if (!authenticated) {
            sendResponse("-ERR Authentication required");
            return;
        }

        // Clear deletion marks
        markedForDeletion.clear();
        sendResponse("+OK Deletion marks reset");
    }

    private void handleNoop() {
        if (!authenticated) {
            sendResponse("-ERR Authentication required");
            return;
        }
        sendResponse("+OK");
    }

    private void handleUidl(String argument) {
        if (!authenticated) {
            sendResponse("-ERR Authentication required");
            return;
        }

        refreshEmails();

        if (argument.isEmpty()) {
            // Send UIDL for all messages
            sendResponse("+OK");
            int index = 1;
            for (MailMessageDB email : emails) {
                if (!isMarkedForDeletion(email.getId())) {
                    sendResponse(index + " " + email.getId());
                    index++;
                }
            }
            sendResponse(".");
        } else {
            // Send UIDL for specific message
            try {
                int msgNum = Integer.parseInt(argument);
                MailMessageDB email = getEmailByMsgNumber(msgNum);
                
                if (email == null) {
                    sendResponse("-ERR No such message");
                } else {
                    sendResponse("+OK " + msgNum + " " + email.getId());
                }
            } catch (NumberFormatException e) {
                sendResponse("-ERR Invalid message number");
            }
        }
    }

    private void handleTop(String argument) {
        if (!authenticated) {
            sendResponse("-ERR Authentication required");
            return;
        }

        refreshEmails();

        String[] parts = argument.split(" ");
        if (parts.length < 2) {
            sendResponse("-ERR Syntax: TOP msg n");
            return;
        }

        try {
            int msgNum = Integer.parseInt(parts[0]);
            int lineCount = Integer.parseInt(parts[1]);
            
            MailMessageDB email = getEmailByMsgNumber(msgNum);
            
            if (email == null) {
                sendResponse("-ERR No such message");
                return;
            }

            String emailContent = email.toEmailFormat();
            String[] lines = emailContent.split("\r\n");
            
            // Find end of headers (empty line)
            int headerEnd = 0;
            for (int i = 0; i < lines.length; i++) {
                if (lines[i].isEmpty()) {
                    headerEnd = i;
                    break;
                }
            }

            sendResponse("+OK");
            
            // Send headers
            for (int i = 0; i <= headerEnd; i++) {
                sendResponse(lines[i]);
            }
            
            // Send requested number of body lines
            int bodyLines = Math.min(lineCount, lines.length - headerEnd - 1);
            for (int i = headerEnd + 1; i < headerEnd + 1 + bodyLines; i++) {
                sendResponse(lines[i]);
            }
            
            sendResponse(".");
            
        } catch (NumberFormatException e) {
            sendResponse("-ERR Invalid arguments");
        }
    }

    private void handleQuit() {
        if (authenticated) {
            // Apply deletions
            for (int emailId : markedForDeletion) {
                boolean deleted = EmailDAO.deleteEmail(emailId, username);
                if (deleted) {
                    logger("Deleted email ID: " + emailId);
                } else {
                    logger("Failed to delete email ID: " + emailId);
                }
            }
            markedForDeletion.clear();
        }

        sendResponse("+OK POP3 server signing off");
    }

    private void refreshEmails() {
        try {
            List<MailMessageDB> freshEmails = EmailDAO.fetchEmails(username);
            
            // Update email list while preserving deletion marks
            Map<Integer, MailMessageDB> emailMap = new HashMap<>();
            for (MailMessageDB email : freshEmails) {
                emailMap.put(email.getId(), email);
            }
            
            // Remove emails that no longer exist or are marked deleted
            markedForDeletion.removeIf(id -> !emailMap.containsKey(id));
            
            emails = freshEmails;
            
        } catch (Exception e) {
            logger("Error refreshing emails: " + e.getMessage());
        }
    }

    private int getActiveEmailCount() {
        int count = 0;
        for (MailMessageDB email : emails) {
            if (!isMarkedForDeletion(email.getId())) {
                count++;
            }
        }
        return count;
    }

    private long getTotalEmailSize() {
        long size = 0;
        for (MailMessageDB email : emails) {
            if (!isMarkedForDeletion(email.getId())) {
                size += email.getContent().length();
            }
        }
        return size;
    }

    private MailMessageDB getEmailByMsgNumber(int msgNum) {
        int index = 1;
        for (MailMessageDB email : emails) {
            if (!isMarkedForDeletion(email.getId())) {
                if (index == msgNum) {
                    return email;
                }
                index++;
            }
        }
        return null;
    }

    private boolean isMarkedForDeletion(int emailId) {
        return markedForDeletion.contains(emailId);
    }
}