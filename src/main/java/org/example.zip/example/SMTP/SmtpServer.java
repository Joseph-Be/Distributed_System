package org.example.SMTP;

import java.io.*;
import java.net.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.example.common.ServerEventListener;
import org.example.common.ServerLogger;
import org.example.database.EmailDAO;
import org.example.database.UserDAO;

public class SmtpServer {
    // Le serveur utilise maintenant le port via le contrôleur
}

class SmtpSession extends Thread {
    private Socket socket;
    private BufferedReader in;
    private PrintWriter out;
    private final SmtpServerController controller;
    private final ServerEventListener listener;
    private final ServerLogger logger;
    private final String clientId;

    // Finite state machine for the SMTP session
    private enum SmtpState {
        CONNECTED,      // Connection established; waiting for HELO/EHLO.
        HELO_RECEIVED,  // HELO/EHLO received; ready for MAIL FROM.
        MAIL_FROM_SET,  // MAIL FROM command processed; ready for RCPT TO.
        RCPT_TO_SET,    // At least one RCPT TO received; ready for DATA.
        DATA_RECEIVING  // DATA command received; reading email content.
    }

    private SmtpState state;
    private String sender;
    private List<String> recipients;
    private StringBuilder dataBuffer;
    private String currentSubject;
    private String currentData;

    public SmtpSession(Socket socket, SmtpServerController controller, 
                       ServerEventListener listener, String clientId) {
        this.socket = socket;
        this.state = SmtpState.CONNECTED;
        this.recipients = new ArrayList<>();
        this.dataBuffer = new StringBuilder();
        this.controller = controller;
        this.listener = listener;
        this.logger = new ServerLogger(listener);
        this.clientId = clientId;
        this.currentSubject = "";
    }

    @Override
    public void run() {
        try {
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out = new PrintWriter(socket.getOutputStream(), true);

            // Send initial greeting
            out.println("220 mail.example.com Service Ready");
            logger.server("220 mail.example.com Service Ready");

            String line;
            while ((line = in.readLine()) != null) {
                logger.client(clientId, line);

                if (state == SmtpState.DATA_RECEIVING) {
                    if (line.equals(".")) {
                        // Process and store the email
                        storeEmailInDatabase(dataBuffer.toString());
                        dataBuffer.setLength(0);
                        state = SmtpState.HELO_RECEIVED;
                        sendResponse("250 OK: Message accepted for delivery");
                    } else {
                        // Extract subject during data phase
                        if (line.toLowerCase().startsWith("subject:")) {
                            currentSubject = line.substring(8).trim();
                        }
                        dataBuffer.append(line).append("\r\n");
                    }
                    continue;
                }

                // Process commands outside of DATA state
                String command = extractToken(line).toUpperCase();
                String argument = extractArgument(line);

                switch (command) {
                    case "HELO":
                    case "EHLO":
                        handleHelo(argument);
                        break;
                    case "MAIL":
                        handleMailFrom(argument);
                        break;
                    case "RCPT":
                        handleRcptTo(argument);
                        break;
                    case "DATA":
                        handleData();
                        break;
                    case "QUIT":
                        handleQuit();
                        return;
                    case "RSET":
                        handleRset();
                        break;
                    case "NOOP":
                        sendResponse("250 OK");
                        break;
                    case "VRFY":
                        handleVrfy(argument);
                        break;
                    default:
                        sendResponse("500 Command unrecognized");
                        break;
                }
            }

            if (state == SmtpState.DATA_RECEIVING) {
                logger.error("Connection interrupted during DATA phase. Email incomplete, not stored.");
            }
        } catch (IOException e) {
            logger.error("SMTP session error: " + e.getMessage());
        } finally {
            try { 
                socket.close(); 
                controller.removeClient(socket);
            } catch (IOException e) { /* ignore */ }
        }
    }

    private void sendResponse(String response) {
        out.println(response);
        logger.server(response);
    }

    private void handleHelo(String arg) {
        state = SmtpState.HELO_RECEIVED;
        sender = "";
        recipients.clear();
        currentSubject = "";
        dataBuffer.setLength(0);
        
        sendResponse("250 Hello " + arg);
    }

    private void handleMailFrom(String arg) {
        if (state != SmtpState.HELO_RECEIVED) {
            sendResponse("503 Bad sequence of commands");
            return;
        }

        // Check format: FROM:<email> or FROM:<email> SP options
        Pattern pattern = Pattern.compile("^FROM:\\s*<([^>]+)>", Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(arg);
        
        if (!matcher.find()) {
            sendResponse("501 Syntax error in parameters or arguments");
            return;
        }

        String email = matcher.group(1).trim();
        
        // Validate email format
        if (!isValidEmail(email)) {
            sendResponse("501 Invalid email address");
            return;
        }

        // Verify sender exists in database
        String username = extractUsername(email);
        if (!UserDAO.userExists(username)) {
            sendResponse("550 Sender not found");
            return;
        }

        sender = email;
        state = SmtpState.MAIL_FROM_SET;
        sendResponse("250 OK");
    }

    private void handleRcptTo(String arg) {
        if (state != SmtpState.MAIL_FROM_SET && state != SmtpState.RCPT_TO_SET) {
            sendResponse("503 Bad sequence of commands");
            return;
        }

        Pattern pattern = Pattern.compile("^TO:\\s*<([^>]+)>", Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(arg);
        
        if (!matcher.find()) {
            sendResponse("501 Syntax error in parameters or arguments");
            return;
        }

        String email = matcher.group(1).trim();
        
        if (!isValidEmail(email)) {
            sendResponse("501 Invalid email address");
            return;
        }

        // Check if recipient exists (optional - can accept any recipient)
        String username = extractUsername(email);
        if (!UserDAO.userExists(username)) {
            // You can choose to accept or reject based on requirements
            // For now, we'll accept but log warning
            logger.info("Recipient not found in database: " + username);
        }

        recipients.add(email);
        state = SmtpState.RCPT_TO_SET;
        sendResponse("250 OK");
    }

    private void handleData() {
        if (state != SmtpState.RCPT_TO_SET || recipients.isEmpty()) {
            sendResponse("503 Bad sequence of commands");
            return;
        }
        state = SmtpState.DATA_RECEIVING;
        currentSubject = "";
        sendResponse("354 Start mail input; end with <CRLF>.<CRLF>");
    }

    private void handleQuit() {
        sendResponse("221 mail.example.com Service closing transmission channel");
    }

    private void handleRset() {
        state = SmtpState.HELO_RECEIVED;
        sender = "";
        recipients.clear();
        currentSubject = "";
        dataBuffer.setLength(0);
        sendResponse("250 OK");
    }

    private void handleVrfy(String arg) {
        // VRFY command - verify if a user exists
        String username = extractUsername(arg);
        if (UserDAO.userExists(username)) {
            sendResponse("250 " + arg);
        } else {
            sendResponse("550 User not found");
        }
    }

    private void storeEmailInDatabase(String data) {
        if (sender == null || recipients.isEmpty()) {
            logger.error("Cannot store email: missing sender or recipients");
            return;
        }

        // Extract subject if not already captured
        if (currentSubject.isEmpty()) {
            currentSubject = extractSubject(data);
        }

        // Store email for each recipient in database
        for (String recipient : recipients) {
            try {
                int emailId = EmailDAO.storeEmail(sender, recipient, currentSubject, data);
                if (emailId > 0) {
                    logger.info("Email stored in database for " + recipient + " (ID: " + emailId + ")");
                    listener.onLog("[SMTP] Email stored: " + sender + " -> " + recipient);
                } else {
                    logger.error("Failed to store email for " + recipient);
                }
            } catch (Exception e) {
                logger.error("Database error: " + e.getMessage());
            }
        }
    }

    private String extractSubject(String data) {
        String[] lines = data.split("\r\n");
        for (String line : lines) {
            if (line.toLowerCase().startsWith("subject:")) {
                return line.substring(8).trim();
            }
        }
        return "No Subject";
    }

    private String extractToken(String line) {
        String[] parts = line.split(" ");
        return parts.length > 0 ? parts[0] : "";
    }

    private String extractArgument(String line) {
        int index = line.indexOf(' ');
        return index > 0 ? line.substring(index).trim() : "";
    }

    private boolean isValidEmail(String email) {
        String regex = "^[A-Za-z0-9+_.-]+@(.+)$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }

    private String extractUsername(String email) {
        int atIndex = email.indexOf('@');
        if (atIndex > 0) {
            return email.substring(0, atIndex);
        }
        return email;
    }
}