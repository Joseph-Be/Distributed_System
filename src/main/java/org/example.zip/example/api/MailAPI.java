// org/example/api/MailAPI.java
package org.example.api;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import io.javalin.Javalin;
import io.javalin.http.Context;
import io.javalin.http.Header;

import org.example.rmi.RemoteUserStore;

import java.io.*;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * API REST — authentification via RMI (AuthService),
 * lecture des mails via IMAP (ImapServer sur port 1143),
 * envoi des mails via SMTP (SmtpServer sur port 50025).
 *
 * Aucun appel direct à la base de données.
 */
public class MailAPI {

    private static final Gson gson = new Gson();

    // token -> username  (sessions HTTP)
    private static final Map<String, String> sessions = new ConcurrentHashMap<>();

    // Ports des serveurs internes
    private static final String SMTP_HOST = "localhost";
    private static final int    SMTP_PORT = 50025;
    private static final String IMAP_HOST = "localhost";
    private static final int    IMAP_PORT = 1143;

    // token -> { restId -> imapSeq }
    private static final Map<String, Map<Integer, Integer>> seqMaps = new ConcurrentHashMap<>();

    public static void main(String[] args) {
        Javalin app = Javalin.create().start(8080);

        // CORS
        app.before(ctx -> {
            ctx.header(Header.ACCESS_CONTROL_ALLOW_ORIGIN,  "*");
            ctx.header(Header.ACCESS_CONTROL_ALLOW_METHODS, "GET, POST, PUT, DELETE, OPTIONS");
            ctx.header(Header.ACCESS_CONTROL_ALLOW_HEADERS, "Authorization, Content-Type");
            if (ctx.method().toString().equals("OPTIONS")) {
                ctx.status(200).result("OK");
            }
        });

        // Routes publiques
        app.post("/api/login",  MailAPI::handleLogin);
        app.post("/api/logout", MailAPI::handleLogout);

        // Routes protégées
        app.before("/api/*", MailAPI::authenticate);
        app.get   ("/api/emails",           MailAPI::handleGetEmails);
        app.get   ("/api/emails/{id}",      MailAPI::handleGetEmail);
        app.post  ("/api/emails",           MailAPI::handleSendEmail);
        app.delete("/api/emails/{id}",      MailAPI::handleDeleteEmail);
        app.put   ("/api/emails/{id}/seen", MailAPI::handleMarkSeen);

        System.out.println("API REST démarrée sur http://localhost:8080");
    }

    // ── middleware d'authentification ────────────────────────────────────────
    private static void authenticate(Context ctx) {
        String path = ctx.path();
        if (path.equals("/api/login") || path.equals("/api/logout")) return;

        String header = ctx.header("Authorization");
        if (header == null || !header.startsWith("Bearer ")) {
            ctx.status(401).json(Map.of("error", "Missing or invalid token"));
            return;
        }
        String token    = header.substring(7);
        String username = sessions.get(token);
        if (username == null) {
            ctx.status(401).json(Map.of("error", "Invalid or expired token"));
            return;
        }
        ctx.attribute("username", username);
        ctx.attribute("token",    token);
    }

    // ── POST /api/login ──────────────────────────────────────────────────────
    private static void handleLogin(Context ctx) {
        JsonObject body     = gson.fromJson(ctx.body(), JsonObject.class);
        String     username = body.get("username").getAsString();
        String     password = body.get("password").getAsString();

        // Authentification via RMI → AuthService (pas de DB directe)
        String rmiToken = RemoteUserStore.login(username, password);
        if (rmiToken != null) {
            String sessionToken = UUID.randomUUID().toString();
            sessions.put(sessionToken, username);
            seqMaps.put(sessionToken, new ConcurrentHashMap<>());
            ctx.json(Map.of("token", sessionToken, "username", username));
        } else {
            ctx.status(401).json(Map.of("error", "Invalid credentials"));
        }
    }

    // ── POST /api/logout ─────────────────────────────────────────────────────
    private static void handleLogout(Context ctx) {
        String token = ctx.attribute("token");
        if (token != null) {
            String username = sessions.remove(token);
            seqMaps.remove(token);
            if (username != null) RemoteUserStore.logout(username, token);
        }
        ctx.json(Map.of("message", "Logged out successfully"));
    }

    // ── GET /api/emails ──────────────────────────────────────────────────────
    private static void handleGetEmails(Context ctx) {
        String username = ctx.attribute("username");
        String token    = ctx.attribute("token");
        try {
            ctx.json(imapFetchList(username, token));
        } catch (Exception e) {
            ctx.status(502).json(Map.of("error", "IMAP error: " + e.getMessage()));
        }
    }

    // ── GET /api/emails/{id} ─────────────────────────────────────────────────
    private static void handleGetEmail(Context ctx) {
        String username = ctx.attribute("username");
        String token    = ctx.attribute("token");
        int    restId   = Integer.parseInt(ctx.pathParam("id"));
        try {
            Map<String, Object> email = imapFetchOne(username, token, restId);
            if (email == null) ctx.status(404).json(Map.of("error", "Email not found"));
            else               ctx.json(email);
        } catch (Exception e) {
            ctx.status(502).json(Map.of("error", "IMAP error: " + e.getMessage()));
        }
    }

    // ── POST /api/emails ─────────────────────────────────────────────────────
    private static void handleSendEmail(Context ctx) {
        String     from    = ctx.attribute("username");
        JsonObject body    = gson.fromJson(ctx.body(), JsonObject.class);
        String     to      = body.get("to").getAsString();
        String     subject = body.get("subject").getAsString();
        String     content = body.get("content").getAsString();

        // Plusieurs destinataires séparés par des virgules
        String[] recipients = Arrays.stream(to.split(","))
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .toArray(String[]::new);

        if (recipients.length == 0) {
            ctx.status(400).json(Map.of("error", "No valid recipients"));
            return;
        }
        try {
            smtpSend(from + "@mail.example.com", recipients, subject, content);
            ctx.status(201).json(Map.of("message", "Email sent", "recipients", recipients.length));
        } catch (Exception e) {
            ctx.status(502).json(Map.of("error", "SMTP error: " + e.getMessage()));
        }
    }

    // ── DELETE /api/emails/{id} ──────────────────────────────────────────────
    private static void handleDeleteEmail(Context ctx) {
        String username = ctx.attribute("username");
        String token    = ctx.attribute("token");
        int    restId   = Integer.parseInt(ctx.pathParam("id"));
        try {
            if (imapDelete(username, token, restId)) ctx.json(Map.of("message", "Email deleted"));
            else ctx.status(404).json(Map.of("error", "Email not found"));
        } catch (Exception e) {
            ctx.status(502).json(Map.of("error", "IMAP error: " + e.getMessage()));
        }
    }

    // ── PUT /api/emails/{id}/seen ────────────────────────────────────────────
    private static void handleMarkSeen(Context ctx) {
        String username = ctx.attribute("username");
        String token    = ctx.attribute("token");
        int    restId   = Integer.parseInt(ctx.pathParam("id"));
        try {
            if (imapMarkSeen(username, token, restId)) ctx.json(Map.of("message", "Email marked as seen"));
            else ctx.status(404).json(Map.of("error", "Email not found"));
        } catch (Exception e) {
            ctx.status(502).json(Map.of("error", "IMAP error: " + e.getMessage()));
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  IMAP helpers
    // ════════════════════════════════════════════════════════════════════════

    private static List<Map<String, Object>> imapFetchList(String username, String token)
            throws Exception {
        List<Map<String, Object>> result = new ArrayList<>();
        Map<Integer, Integer> seqMap = seqMaps.computeIfAbsent(token, k -> new ConcurrentHashMap<>());
        seqMap.clear();

        try (Socket sock = new Socket(IMAP_HOST, IMAP_PORT);
             BufferedReader in  = new BufferedReader(new InputStreamReader(sock.getInputStream()));
             PrintWriter    out = new PrintWriter(new OutputStreamWriter(sock.getOutputStream()), true)) {

            in.readLine(); // greeting
            sendCmd(out, in, "A001 LOGIN " + username + " " + getSessionToken(username));
            String selectResp = sendCmd(out, in, "A002 SELECT INBOX");

            int msgCount = parseExists(selectResp);
            if (msgCount == 0) { sendCmd(out, in, "A003 LOGOUT"); return result; }

            String fetchResp = sendCmd(out, in, "A003 FETCH 1:" + msgCount + " (FLAGS ENVELOPE)");
            sendCmd(out, in, "A004 LOGOUT");

            List<String[]> envelopes = parseEnvelopes(fetchResp);
            AtomicInteger restId = new AtomicInteger(1);
            for (String[] env : envelopes) {
                int id = restId.getAndIncrement();
                seqMap.put(id, Integer.parseInt(env[0]));
                Map<String, Object> m = new HashMap<>();
                m.put("id",      id);
                m.put("from",    env[1]);
                m.put("subject", env[2]);
                m.put("date",    env[3]);
                m.put("seen",    env[4].contains("\\Seen"));
                result.add(m);
            }
        }
        return result;
    }

    private static Map<String, Object> imapFetchOne(String username, String token, int restId)
            throws Exception {
        Map<Integer, Integer> seqMap = seqMaps.computeIfAbsent(token, k -> new ConcurrentHashMap<>());
        if (!seqMap.containsKey(restId)) {
            imapFetchList(username, token);
        }
        Integer seq = seqMap.get(restId);
        if (seq == null) return null;

        try (Socket sock = new Socket(IMAP_HOST, IMAP_PORT);
             BufferedReader in  = new BufferedReader(new InputStreamReader(sock.getInputStream()));
             PrintWriter    out = new PrintWriter(new OutputStreamWriter(sock.getOutputStream()), true)) {

            in.readLine();
            sendCmd(out, in, "B001 LOGIN " + username + " " + getSessionToken(username));
            sendCmd(out, in, "B002 SELECT INBOX");
            String bodyResp = sendCmd(out, in, "B003 FETCH " + seq + " (FLAGS ENVELOPE BODY[])");
            sendCmd(out, in, "B004 STORE " + seq + " +FLAGS (\\Seen)");
            sendCmd(out, in, "B005 LOGOUT");
            return parseFullMessage(bodyResp, restId);
        }
    }

    private static boolean imapDelete(String username, String token, int restId) throws Exception {
        Map<Integer, Integer> seqMap = seqMaps.getOrDefault(token, Collections.emptyMap());
        Integer seq = seqMap.get(restId);
        if (seq == null) return false;

        try (Socket sock = new Socket(IMAP_HOST, IMAP_PORT);
             BufferedReader in  = new BufferedReader(new InputStreamReader(sock.getInputStream()));
             PrintWriter    out = new PrintWriter(new OutputStreamWriter(sock.getOutputStream()), true)) {

            in.readLine();
            sendCmd(out, in, "C001 LOGIN " + username + " " + getSessionToken(username));
            sendCmd(out, in, "C002 SELECT INBOX");
            sendCmd(out, in, "C003 STORE " + seq + " +FLAGS (\\Deleted)");
            sendCmd(out, in, "C004 EXPUNGE");
            sendCmd(out, in, "C005 LOGOUT");
        }
        seqMap.remove(restId);
        return true;
    }

    private static boolean imapMarkSeen(String username, String token, int restId) throws Exception {
        Map<Integer, Integer> seqMap = seqMaps.getOrDefault(token, Collections.emptyMap());
        Integer seq = seqMap.get(restId);
        if (seq == null) return false;

        try (Socket sock = new Socket(IMAP_HOST, IMAP_PORT);
             BufferedReader in  = new BufferedReader(new InputStreamReader(sock.getInputStream()));
             PrintWriter    out = new PrintWriter(new OutputStreamWriter(sock.getOutputStream()), true)) {

            in.readLine();
            sendCmd(out, in, "D001 LOGIN " + username + " " + getSessionToken(username));
            sendCmd(out, in, "D002 SELECT INBOX");
            sendCmd(out, in, "D003 STORE " + seq + " +FLAGS (\\Seen)");
            sendCmd(out, in, "D004 LOGOUT");
        }
        return true;
    }

    // ════════════════════════════════════════════════════════════════════════
    //  SMTP helper
    // ════════════════════════════════════════════════════════════════════════

    /**
     * Envoi via SmtpServer interne.
     * Supporte plusieurs destinataires et un contenu multi-lignes.
     */
    private static void smtpSend(String from, String[] recipients,
                                  String subject, String content) throws Exception {
        try (Socket sock = new Socket(SMTP_HOST, SMTP_PORT);
             BufferedReader in  = new BufferedReader(new InputStreamReader(sock.getInputStream()));
             PrintWriter    out = new PrintWriter(new OutputStreamWriter(sock.getOutputStream()), true)) {

            expectCode(in, "220");
            out.println("EHLO api.mail.example.com");
            drainUntilOk(in, "250");

            out.println("MAIL FROM:<" + from + ">");
            expectCode(in, "250");

            for (String rcpt : recipients) {
                String rcptAddr = rcpt.contains("@") ? rcpt : rcpt + "@mail.example.com";
                out.println("RCPT TO:<" + rcptAddr + ">");
                expectCode(in, "250");
            }

            out.println("DATA");
            expectCode(in, "354");

            // En-têtes RFC 2822
            out.println("From: " + from);
            out.println("To: " + String.join(", ", recipients));
            out.println("Subject: " + subject);
            out.println("Date: " + new SimpleDateFormat(
                    "EEE, dd MMM yyyy HH:mm:ss Z", Locale.ENGLISH).format(new Date()));
            out.println("MIME-Version: 1.0");
            out.println("Content-Type: text/plain; charset=UTF-8");
            out.println();

            // Corps multi-lignes : on échappe les lignes commençant par "."
            for (String line : content.split("\n")) {
                String l = line.stripTrailing();
                out.println(l.startsWith(".") ? "." + l : l);
            }

            out.println(".");
            expectCode(in, "250");
            out.println("QUIT");
            expectCode(in, "221");
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  IMAP bas niveau
    // ════════════════════════════════════════════════════════════════════════

    private static String sendCmd(PrintWriter out, BufferedReader in, String cmd) throws Exception {
        out.println(cmd);
        String tag = cmd.split(" ")[0];
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = in.readLine()) != null) {
            sb.append(line).append("\n");
            if (line.startsWith(tag + " OK") || line.startsWith(tag + " NO") ||
                line.startsWith(tag + " BAD")) break;
        }
        return sb.toString();
    }

    private static int parseExists(String resp) {
        for (String line : resp.split("\n")) {
            if (line.contains("EXISTS")) {
                try { return Integer.parseInt(line.trim().split(" ")[1]); } catch (Exception ignored) {}
            }
        }
        return 0;
    }

    private static List<String[]> parseEnvelopes(String fetchResp) {
        List<String[]> list = new ArrayList<>();
        String[] lines = fetchResp.split("\n");
        int seq = 0; String from = "", subject = "", date = "", flags = "";
        for (String line : lines) {
            line = line.trim();
            if (line.startsWith("*") && line.contains("FETCH")) {
                try { seq = Integer.parseInt(line.split(" ")[1]); } catch (Exception ignored) {}
                flags = ""; from = ""; subject = ""; date = "";
            }
            if (line.startsWith("FLAGS"))    flags = line;
            if (line.startsWith("ENVELOPE")) {
                String inner = line.replaceFirst("ENVELOPE\\s*\\(", "").replaceAll("\\)$", "");
                String[] parts = splitEnvelope(inner);
                if (parts.length > 0) date    = dequote(parts[0]);
                if (parts.length > 1) subject = dequote(parts[1]);
                if (parts.length > 2) from    = dequote(parts[2]);
                if (seq > 0) { list.add(new String[]{String.valueOf(seq), from, subject, date, flags}); seq = 0; }
            }
        }
        return list;
    }

    private static Map<String, Object> parseFullMessage(String bodyResp, int restId) {
        StringBuilder body = new StringBuilder();
        boolean inBody = false;
        String from = "", subject = "", date = "", flags = "";
        for (String line : bodyResp.split("\n")) {
            String t = line.trim();
            if (t.startsWith("FLAGS"))    flags = t;
            if (t.startsWith("ENVELOPE")) {
                String inner = t.replaceFirst("ENVELOPE\\s*\\(", "").replaceAll("\\)$", "");
                String[] parts = splitEnvelope(inner);
                if (parts.length > 0) date    = dequote(parts[0]);
                if (parts.length > 1) subject = dequote(parts[1]);
                if (parts.length > 2) from    = dequote(parts[2]);
            }
            if (t.startsWith("BODY[]")) { inBody = true; continue; }
            if (inBody && t.startsWith("*")) inBody = false;
            if (inBody) body.append(line).append("\n");
        }
        Map<String, Object> m = new HashMap<>();
        m.put("id", restId); m.put("from", from); m.put("subject", subject);
        m.put("date", date); m.put("seen", flags.contains("\\Seen")); m.put("content", body.toString());
        return m;
    }

    private static String[] splitEnvelope(String s) {
        List<String> parts = new ArrayList<>();
        int depth = 0; boolean inQ = false; StringBuilder cur = new StringBuilder();
        for (char c : s.toCharArray()) {
            if (c == '"' && depth == 0) { inQ = !inQ; cur.append(c); }
            else if (!inQ && c == '(')  { depth++; cur.append(c); }
            else if (!inQ && c == ')')  { depth--; cur.append(c); }
            else if (!inQ && c == ' ' && depth == 0) { parts.add(cur.toString()); cur.setLength(0); }
            else cur.append(c);
        }
        if (cur.length() > 0) parts.add(cur.toString());
        return parts.toArray(new String[0]);
    }

    private static String dequote(String s) {
        if (s == null) return "";
        s = s.trim();
        if (s.startsWith("\"") && s.endsWith("\"")) return s.substring(1, s.length() - 1);
        return s.equals("NIL") ? "" : s;
    }

    // ════════════════════════════════════════════════════════════════════════
    //  SMTP bas niveau
    // ════════════════════════════════════════════════════════════════════════

    private static void expectCode(BufferedReader in, String code) throws Exception {
        String line = in.readLine();
        if (line == null || !line.startsWith(code))
            throw new IOException("Expected " + code + ", got: " + line);
    }

    private static void drainUntilOk(BufferedReader in, String code) throws Exception {
        String line;
        while ((line = in.readLine()) != null) {
            if (line.startsWith(code + " ")) break;
        }
    }

    // Retourne le token de session pour un utilisateur (utilisé comme password IMAP)
    private static String getSessionToken(String username) {
        return sessions.entrySet().stream()
               .filter(e -> e.getValue().equals(username))
               .map(Map.Entry::getKey)
               .findFirst()
               .orElse("__no_token__");
    }
}
